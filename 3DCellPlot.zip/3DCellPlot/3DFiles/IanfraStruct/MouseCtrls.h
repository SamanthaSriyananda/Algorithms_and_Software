// ============================================================
// Mouse controls for 3D OpenGL plot
// ============================================================
#ifndef MOUSECTRLS_H
#define MOUSECTRLS_H

#include <windows.h>
#include <cmath>

// ============================================================
// Mouse state
// ============================================================
bool leftMouseDown = false;
bool rightMouseDown = false;

int lastMouseX = 0;
int lastMouseY = 0;

// ============================================================
// Camera / viewing controls
// ============================================================
float cameraX = 0.0f;
float cameraY = 0.0f;
float viewScale = 1.4f;

// ============================================================
// Mouse sensitivity
// ============================================================
float mouseRotateSpeed = 0.5f;
float mousePanSpeed = 0.005f;
float mouseZoomSpeed = 0.0015f;

// ============================================================
// Zoom limits
// ============================================================
const float MIN_VIEW_SCALE = 0.2f;
const float MAX_VIEW_SCALE = 10.0f;

// ============================================================
// Windows window procedure
// ============================================================
WNDPROC originalWindowProc = nullptr;

// ============================================================
// Apply zoom
// ============================================================
void applyZoom(float amount)
{
    viewScale += amount;

    if (viewScale < MIN_VIEW_SCALE) viewScale = MIN_VIEW_SCALE;
    if (viewScale > MAX_VIEW_SCALE) viewScale = MAX_VIEW_SCALE;

    glutPostRedisplay();
}

// ============================================================
// Apply orthographic projection
// ============================================================
// Call this from display() before drawing the model.
void applyMouseProjection()
{
    int width = glutGet(GLUT_WINDOW_WIDTH);
    int height = glutGet(GLUT_WINDOW_HEIGHT);

    if (height == 0) height = 1;

    float aspect = static_cast<float>(width) / static_cast<float>(height);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    if (aspect >= 1.0f)
    {
        glOrtho(-viewScale * aspect, viewScale * aspect,
                -viewScale, viewScale,
                -10.0f, 10.0f);
    }
    else
    {
        glOrtho(-viewScale, viewScale,
                -viewScale / aspect, viewScale / aspect,
                -10.0f, 10.0f);
    }

    glMatrixMode(GL_MODELVIEW);
}

// ============================================================
// Mouse button callback
// ============================================================
void mouseButton(int button, int state, int x, int y)
{
    // Left mouse button = Rotate
    if (button == GLUT_LEFT_BUTTON)
    {
        if (state == GLUT_DOWN)
        {
            leftMouseDown = true;
            lastMouseX = x;
            lastMouseY = y;
        }
        else if (state == GLUT_UP)
        {
            leftMouseDown = false;
        }
    }

    // Right mouse button = Pan
    if (button == GLUT_RIGHT_BUTTON)
    {
        if (state == GLUT_DOWN)
        {
            rightMouseDown = true;
            lastMouseX = x;
            lastMouseY = y;
        }
        else if (state == GLUT_UP)
        {
            rightMouseDown = false;
        }
    }

    // Traditional mouse wheel
    // FreeGLUT: Button 3 = Wheel up, Button 4 = Wheel down
    if (button == 3 && state == GLUT_DOWN) applyZoom(-0.10f);
    if (button == 4 && state == GLUT_DOWN) applyZoom(0.10f);

    glutPostRedisplay();
}

// ============================================================
// Mouse motion callback
// ============================================================
void mouseMotion(int x, int y)
{
    int dx = x - lastMouseX;
    int dy = y - lastMouseY;

    // Left drag = Rotate
    if (leftMouseDown)
    {
        rotateY += dx * mouseRotateSpeed;
        rotateX += dy * mouseRotateSpeed;
    }

    // Right drag = Pan
    if (rightMouseDown)
    {
        cameraX += dx * mousePanSpeed;
        cameraY -= dy * mousePanSpeed;
    }

    lastMouseX = x;
    lastMouseY = y;

    glutPostRedisplay();
}

// ============================================================
// Windows message handler
// ============================================================
// Handles:
// WM_MOUSEWHEEL
// WM_GESTURE
LRESULT CALLBACK MouseWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    // Windows mouse wheel
    if (message == WM_MOUSEWHEEL)
    {
        short wheelDelta = static_cast<short>(HIWORD(wParam));
        float steps = static_cast<float>(wheelDelta) / static_cast<float>(WHEEL_DELTA);

        applyZoom(-steps * 0.10f);

        return 0;
    }

    // Windows gesture messages
    if (message == WM_GESTURE)
    {
        GESTUREINFO gestureInfo;
        ZeroMemory(&gestureInfo, sizeof(GESTUREINFO));
        gestureInfo.cbSize = sizeof(GESTUREINFO);

        if (GetGestureInfo(reinterpret_cast<HGESTUREINFO>(lParam), &gestureInfo))
        {
            // Pinch / zoom gesture
            if (gestureInfo.dwID == GID_ZOOM)
            {
                static ULONGLONG previousZoomArguments = 0;
                ULONGLONG currentZoomArguments = gestureInfo.ullArguments;

                if (gestureInfo.dwFlags & GF_BEGIN)
                {
                    previousZoomArguments = currentZoomArguments;
                }
                else if (previousZoomArguments != 0)
                {
                    LONG previousDistance = static_cast<LONG>(previousZoomArguments);
                    LONG currentDistance = static_cast<LONG>(currentZoomArguments);
                    LONG difference = currentDistance - previousDistance;

                    if (difference != 0)
                    {
                        float zoomAmount = -static_cast<float>(difference) * 0.0005f;
                        applyZoom(zoomAmount);
                    }

                    previousZoomArguments = currentZoomArguments;
                }
            }

            CloseGestureInfoHandle(reinterpret_cast<HGESTUREINFO>(lParam));
            return 0;
        }
    }

    // Pass everything else to the original GLUT procedure
    return CallWindowProc(originalWindowProc, hWnd, message, wParam, lParam);
}

// ============================================================
// Install Windows message handler
// ============================================================
// Call this AFTER glutCreateWindow()
void installMouseWindowProc()
{
    HWND hWnd = FindWindow(nullptr, TEXT("3D Point-in-Polyhedron"));

    if (hWnd == nullptr)
    {
        MessageBox(nullptr,
                   TEXT("Could not find GLUT window."),
                   TEXT("Mouse Controls"),
                   MB_OK | MB_ICONWARNING);
        return;
    }

    // Get current GLUT window procedure
    originalWindowProc = reinterpret_cast<WNDPROC>(GetWindowLongPtr(hWnd, GWLP_WNDPROC));

    // Replace it with our procedure
    SetWindowLongPtr(hWnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(MouseWindowProc));
}

// ============================================================
// Reset view
// ============================================================
void resetMouseView()
{
    viewScale = 1.4f;
    cameraX = 0.0f;
    cameraY = 0.0f;
    rotateX = 0.0f;
    rotateY = 0.0f;
    rotateZ = 0.0f;

    glutPostRedisplay();
}

#endif