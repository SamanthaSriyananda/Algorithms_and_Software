// ------------------------------------------------------------
// Sphere points generation
// ------------------------------------------------------------
#ifndef SPHEREPOINTS_H
#define SPHEREPOINTS_H

#include <iostream>
#include <fstream>
#include <cmath>
#include <random>

void SpherePoints(const double PI, int rings, int sectors)
{

    // Sphere parameters
    double radius = 1.0;

    // Output file
    ofstream pfile("3DFiles/IanfraStruct/sphere_points.txt");

    if (!pfile.is_open())
    {
        cerr << "Error: Could not open output file!" << endl;
        return;
    }

    // -----------------------------
    // Latitude lines (Rings)
    // -----------------------------
    for (int i = 0; i <= rings; i++)
    {
        double phi = PI * i / rings;

        for (int j = 0; j <= sectors; j++)
        {
            double theta = 2.0 * PI * j / sectors;

            double x = radius * sin(phi) * cos(theta);
            double y = radius * sin(phi) * sin(theta);
            double z = radius * cos(phi);

            pfile << x << " " << y << " " << z << "\n";
        }
    }

    // -----------------------------
    // Longitude lines (Sectors)
    // -----------------------------
    for (int j = 0; j < sectors; j++)
    {
        double theta = 2.0 * PI * j / sectors;

        for (int i = 0; i <= rings; i++)
        {
            double phi = PI * i / rings;

            double x = radius * sin(phi) * cos(theta);
            double y = radius * sin(phi) * sin(theta);
            double z = radius * cos(phi);

            pfile << x << " " << y << " " << z << "\n";
        }
    }

    pfile.close();
    cout << "Sphere data points saved to sphere_points.txt" << endl;
}

#endif