// ------------------------------------------------------------
// Draw text
// ------------------------------------------------------------

#ifndef DRAWTEXT_H
#define DRAWTEXT_H

void drawText(float x, float y, float z, const char* text)
{
    glRasterPos3f(x, y, z);

    for (const char* c = text; *c != '\0'; c++)
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
}

#endif