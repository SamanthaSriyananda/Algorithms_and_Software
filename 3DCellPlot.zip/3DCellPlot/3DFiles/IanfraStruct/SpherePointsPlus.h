// ------------------------------------------------------------
// Sphere points generation
// ------------------------------------------------------------
#ifndef SPHEREPOINTSPLUS_H
#define SPHEREPOINTSPLUS_H

#include <cmath>

// Random number generator
random_device rd;
mt19937 gen(rd());

void SpherePointsPlus(const double PI, int rings, int sectors)
{

    // Sphere parameters
    double radius = 1.0;

    uniform_real_distribution<double> outward(0.0, 0.3); // Random outward displacement: 0% to 30% outward displacement
    ofstream pfile("3DFiles/IanfraStruct/sphere_pointsPlus.txt");     // Output file

    if (!pfile.is_open())
    {
        cerr << "Error: Could not open output file!" << endl;
        return;
    }

    // -----------------------------
    // Latitude lines (Rings)
    // -----------------------------
    for (int i = 0; i <= rings; i++)
    {
        double phi = PI * i / rings;

        for (int j = 0; j <= sectors; j++)
        {
            double theta = 2.0 * PI * j / sectors;
            double scale = 1.0 + outward(gen); // Random outward amount: 0% to 10%

            double x = radius * scale * sin(phi) * cos(theta);
            double y = radius * scale * sin(phi) * sin(theta);
            double z = radius * scale * cos(phi);

            pfile << x << " " << y << " " << z << "\n";
        }
    }

    // -----------------------------
    // Longitude lines (Sectors)
    // -----------------------------
    for (int j = 0; j < sectors; j++)
    {
        double theta = 2.0 * PI * j / sectors;

        for (int i = 0; i <= rings; i++)
        {
            double phi = PI * i / rings;
            double scale = 1.0 + outward(gen); // Random outward amount: 0% to 10%

            double x = radius * scale * sin(phi) * cos(theta);
            double y = radius * scale * sin(phi) * sin(theta);
            double z = radius * scale * cos(phi);

            pfile << x << " " << y << " " << z << "\n";
        }
    }

    pfile.close();
    cout << "Sphere data points saved to sphere_pointsPlus.txt" << endl;
}

#endif