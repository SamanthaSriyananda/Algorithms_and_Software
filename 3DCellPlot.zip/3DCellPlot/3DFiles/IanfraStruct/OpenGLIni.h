// ------------------------------------------------------------
// OpenGL initialization
// ------------------------------------------------------------
#ifndef OPENGL_INI_H
#define OPENGL_INI_H

void initOpenGL()
{
    glClearColor(0.9f, 0.9f, 0.9f, 1.0f); // Background color to light gray (R, G, B, A = Alpha (transparency))
    glEnable(GL_NORMALIZE);     // Normalize normal vectors used for lighting
    glShadeModel(GL_SMOOTH);    // Gradually blends the colors/lighting between vertices. 
                                // Makes curved objects look smooth and rounded

    // Sphere specular material
    GLfloat specularMaterial[] = {1.0f, 1.0f, 1.0f, 1.0f}; // White specular/shining highlight (R, G, B, A = Alpha (transparency))
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specularMaterial); // Set specular/shining color 
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 50.0f); // Set shininess of the sphere
}

#endif