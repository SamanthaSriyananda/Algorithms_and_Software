#include <vector>
#include <cuda_runtime.h>
#include <device_launch_parameters.h>
#include <algorithm>
#include <cmath>      // sqrt, fabs
#include "IanfraStruct/DetectDim.h"   // MeshDimensions, Point3D

extern int decision;

struct CudaVec3 { double x, y, z; };

__device__ CudaVec3 sub3(CudaVec3 a, CudaVec3 b) {
    return {a.x-b.x, a.y-b.y, a.z-b.z};
}
__device__ double dot3(CudaVec3 a, CudaVec3 b) {
    return a.x*b.x + a.y*b.y + a.z*b.z;
}
__device__ CudaVec3 cross3(CudaVec3 a, CudaVec3 b) {
    return {a.y*b.z-a.z*b.y, a.z*b.x-a.x*b.z, a.x*b.y-a.y*b.x};
}

__global__ void classifyTrianglesKernel(const CudaVec3* vertices, int triangleCount,
                                        CudaVec3 p, CudaVec3 ray,
                                        double* hitDistances, int* surfaceFlags) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= triangleCount) return;

    CudaVec3 a = vertices[i*3], b = vertices[i*3+1], c = vertices[i*3+2];
    CudaVec3 ab = sub3(b,a), ac = sub3(c,a), ap = sub3(p,a);
    CudaVec3 n = cross3(ab,ac);
    double n2 = dot3(n,n);
    surfaceFlags[i] = 0;
    hitDistances[i] = -1.0;

    if (n2 > 1.0e-30) {
        double plane = dot3(ap,n);
        if (plane*plane <= 1.0e-18*n2) {
            double d00=dot3(ab,ab), d01=dot3(ab,ac), d11=dot3(ac,ac);
            double d20=dot3(ap,ab), d21=dot3(ap,ac);
            double denom=d00*d11-d01*d01;
            if (fabs(denom) > 1.0e-30) {
                double v=(d11*d20-d01*d21)/denom;
                double w=(d00*d21-d01*d20)/denom;
                double u=1.0-v-w;
                if (u >= -1.0e-9 && v >= -1.0e-9 && w >= -1.0e-9)
                    surfaceFlags[i] = 1;
            }
        }
    }

    const double eps=1.0e-12;
    CudaVec3 h=cross3(ray,ac);
    double det=dot3(ab,h);
    if (fabs(det) < eps) return;
    double inv=1.0/det;
    CudaVec3 s=sub3(p,a);
    double u=inv*dot3(s,h);
    if (u < -eps || u > 1.0+eps) return;
    CudaVec3 q=cross3(s,ab);
    double v=inv*dot3(ray,q);
    if (v < -eps || u+v > 1.0+eps) return;
    double t=inv*dot3(ac,q);
    if (t > eps) hitDistances[i]=t;
}

static bool cudaOk(cudaError_t e, const char* where) {
    if (e == cudaSuccess) return true;
    std::cerr << "CUDA classifier error at " << where << ": "
              << cudaGetErrorString(e) << '\n';
    return false;
}

void cudaPointInPolyhedronRayCasting(const MeshDimensions& mesh, const Point3D& tp) {
    const int pointsPerRow=mesh.sectors+1;
    const int required=(mesh.rings+1)*pointsPerRow;
    if (mesh.rings <= 0 || mesh.sectors <= 0 ||
        static_cast<int>(mesh.spherePoints.size()) < required) {
        decision=0;
        return;
    }

    const int triangleCount=mesh.rings*mesh.sectors*2;
    std::vector<CudaVec3> triangles(static_cast<size_t>(triangleCount)*3);
    int k=0;
    for (int r=0; r<mesh.rings; ++r) {
        for (int s=0; s<mesh.sectors; ++s) {
            int i00=r*pointsPerRow+s, i01=i00+1;
            int i10=(r+1)*pointsPerRow+s, i11=i10+1;
            const Point3D& a=mesh.spherePoints[i00];
            const Point3D& b=mesh.spherePoints[i01];
            const Point3D& c=mesh.spherePoints[i10];
            const Point3D& d=mesh.spherePoints[i11];
            triangles[k++]={a.x,a.y,a.z}; triangles[k++]={c.x,c.y,c.z}; triangles[k++]={d.x,d.y,d.z};
            triangles[k++]={a.x,a.y,a.z}; triangles[k++]={d.x,d.y,d.z}; triangles[k++]={b.x,b.y,b.z};
        }
    }

    CudaVec3 *d_triangles=nullptr;
    double *d_hits=nullptr;
    int *d_surface=nullptr;
    std::vector<double> hits(triangleCount);
    std::vector<int> surface(triangleCount);
    bool ok = cudaOk(cudaMalloc(&d_triangles, triangles.size()*sizeof(CudaVec3)), "allocate triangles")
           && cudaOk(cudaMalloc(&d_hits, hits.size()*sizeof(double)), "allocate hits")
           && cudaOk(cudaMalloc(&d_surface, surface.size()*sizeof(int)), "allocate surface flags")
           && cudaOk(cudaMemcpy(d_triangles, triangles.data(), triangles.size()*sizeof(CudaVec3), cudaMemcpyHostToDevice), "copy triangles");

    if (ok) {
        CudaVec3 p{tp.x,tp.y,tp.z};
        const double len=sqrt(1.0+0.371*0.371+0.217*0.217);
        CudaVec3 ray{1.0/len,0.371/len,0.217/len};
        int threads=256, blocks=(triangleCount+threads-1)/threads;
        classifyTrianglesKernel<<<blocks,threads>>>(d_triangles,triangleCount,p,ray,d_hits,d_surface);
        ok=cudaOk(cudaGetLastError(),"launch kernel")
           && cudaOk(cudaDeviceSynchronize(),"synchronize")
           && cudaOk(cudaMemcpy(hits.data(),d_hits,hits.size()*sizeof(double),cudaMemcpyDeviceToHost),"copy hit distances")
           && cudaOk(cudaMemcpy(surface.data(),d_surface,surface.size()*sizeof(int),cudaMemcpyDeviceToHost),"copy surface flags");
    }

    if (d_triangles) cudaFree(d_triangles);
    if (d_hits) cudaFree(d_hits);
    if (d_surface) cudaFree(d_surface);
    if (!ok) { decision=0; return; }

    if (std::find(surface.begin(),surface.end(),1)!=surface.end()) {
        decision=1;
        return;
    }

    hits.erase(std::remove_if(hits.begin(),hits.end(),[](double t){return t < 0.0;}),hits.end());
    std::sort(hits.begin(),hits.end());
    int uniqueHits=0;
    const double tolerance=1.0e-8;
    for (size_t i=0; i<hits.size(); ++i)
        if (i==0 || std::fabs(hits[i]-hits[i-1]) > tolerance) ++uniqueHits;
    decision=(uniqueHits%2) ? 1 : 2;
}

// ------------------------------------------------------------
// CUDA 3D Point-in-Polyhedron - Winding Number
// (GPU version of pointInPolyhedronWindingNumber() in PinPhedron.h)
// ------------------------------------------------------------
// Signed solid angle of one triangle seen from point p (same formula as pp_triangleSolidAngle).
__device__ double triangleSolidAngle3(CudaVec3 p, CudaVec3 a, CudaVec3 b, CudaVec3 c) {
    CudaVec3 A = sub3(a,p), B = sub3(b,p), C = sub3(c,p);
    double lenA = sqrt(dot3(A,A));
    double lenB = sqrt(dot3(B,B));
    double lenC = sqrt(dot3(C,C));
    if (lenA < 1.0e-15 || lenB < 1.0e-15 || lenC < 1.0e-15)
        return 0.0;
    double numerator = dot3(A, cross3(B,C));
    double denominator = lenA*lenB*lenC
                       + dot3(A,B)*lenC
                       + dot3(B,C)*lenA
                       + dot3(C,A)*lenB;
    return 2.0*atan2(numerator, denominator);
}

// Same test as pp_pointOnTriangle() (distance to plane + barycentric check).
__device__ bool pointOnTriangle3(CudaVec3 p, CudaVec3 a, CudaVec3 b, CudaVec3 c, double tolerance) {
    CudaVec3 ab = sub3(b,a), ac = sub3(c,a), ap = sub3(p,a);
    CudaVec3 n = cross3(ab,ac);
    double nLen = sqrt(dot3(n,n));
    if (nLen < 1.0e-15) return false;
    double distance = fabs(dot3(ap,n)) / nLen;
    if (distance > tolerance) return false;

    double d00=dot3(ab,ab), d01=dot3(ab,ac), d11=dot3(ac,ac);
    double d20=dot3(ap,ab), d21=dot3(ap,ac);
    double denom = d00*d11 - d01*d01;
    if (fabs(denom) < 1.0e-15) return false;
    double v = (d11*d20 - d01*d21) / denom;
    double w = (d00*d21 - d01*d20) / denom;
    double u = 1.0 - v - w;
    return u >= -tolerance && v >= -tolerance && w >= -tolerance;
}

// One thread per triangle: solid angle + on-surface flag.
__global__ void windingNumberKernel(const CudaVec3* vertices, int triangleCount,
                                    CudaVec3 p, double surfaceTolerance,
                                    double* solidAngles, int* surfaceFlags) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= triangleCount) return;

    CudaVec3 a = vertices[i*3], b = vertices[i*3+1], c = vertices[i*3+2];
    surfaceFlags[i] = pointOnTriangle3(p, a, b, c, surfaceTolerance) ? 1 : 0;
    solidAngles[i]  = triangleSolidAngle3(p, a, b, c);
}

void cudaPointInPolyhedronWindingNumber(const MeshDimensions& mesh, const Point3D& tp) {
    const double surfaceTolerance = 1.0e-9;
    const double windingTolerance = 0.5;

    const int pointsPerRow = mesh.sectors+1;
    const int required = (mesh.rings+1)*pointsPerRow;
    if (mesh.rings <= 0 || mesh.sectors <= 0 ||
        static_cast<int>(mesh.spherePoints.size()) < required) {
        decision=0;
        return;
    }

    // Same triangle order as the CPU version: ACD then ADB for every quad.
    const int triangleCount = mesh.rings*mesh.sectors*2;
    std::vector<CudaVec3> triangles(static_cast<size_t>(triangleCount)*3);
    int k=0;
    for (int r=0; r<mesh.rings; ++r) {
        for (int s=0; s<mesh.sectors; ++s) {
            int i00=r*pointsPerRow+s, i01=i00+1;
            int i10=(r+1)*pointsPerRow+s, i11=i10+1;
            const Point3D& a=mesh.spherePoints[i00];
            const Point3D& b=mesh.spherePoints[i01];
            const Point3D& c=mesh.spherePoints[i10];
            const Point3D& d=mesh.spherePoints[i11];
            triangles[k++]={a.x,a.y,a.z}; triangles[k++]={c.x,c.y,c.z}; triangles[k++]={d.x,d.y,d.z};
            triangles[k++]={a.x,a.y,a.z}; triangles[k++]={d.x,d.y,d.z}; triangles[k++]={b.x,b.y,b.z};
        }
    }

    CudaVec3 *d_triangles=nullptr;
    double *d_angles=nullptr;
    int *d_surface=nullptr;
    std::vector<double> angles(triangleCount);
    std::vector<int> surface(triangleCount);
    bool ok = cudaOk(cudaMalloc(&d_triangles, triangles.size()*sizeof(CudaVec3)), "allocate triangles")
           && cudaOk(cudaMalloc(&d_angles, angles.size()*sizeof(double)), "allocate solid angles")
           && cudaOk(cudaMalloc(&d_surface, surface.size()*sizeof(int)), "allocate surface flags")
           && cudaOk(cudaMemcpy(d_triangles, triangles.data(), triangles.size()*sizeof(CudaVec3), cudaMemcpyHostToDevice), "copy triangles");

    if (ok) {
        CudaVec3 p{tp.x,tp.y,tp.z};
        int threads=256, blocks=(triangleCount+threads-1)/threads;
        windingNumberKernel<<<blocks,threads>>>(d_triangles,triangleCount,p,surfaceTolerance,d_angles,d_surface);
        ok=cudaOk(cudaGetLastError(),"launch winding kernel")
           && cudaOk(cudaDeviceSynchronize(),"synchronize")
           && cudaOk(cudaMemcpy(angles.data(),d_angles,angles.size()*sizeof(double),cudaMemcpyDeviceToHost),"copy solid angles")
           && cudaOk(cudaMemcpy(surface.data(),d_surface,surface.size()*sizeof(int),cudaMemcpyDeviceToHost),"copy surface flags");
    }

    if (d_triangles) cudaFree(d_triangles);
    if (d_angles) cudaFree(d_angles);
    if (d_surface) cudaFree(d_surface);
    if (!ok) { decision=0; return; }

    // On the surface -> inside (same as CPU version).
    if (std::find(surface.begin(),surface.end(),1)!=surface.end()) {
        decision=1;
        return;
    }

    // Sum on the host in triangle order (deterministic, same order as CPU version).
    const double PI = std::acos(-1.0);
    double totalSolidAngle = 0.0;
    for (size_t i=0; i<angles.size(); ++i) totalSolidAngle += angles[i];
    double winding = totalSolidAngle / (4.0*PI);

    decision = (std::fabs(winding) > windingTolerance) ? 1 : 2;
}
