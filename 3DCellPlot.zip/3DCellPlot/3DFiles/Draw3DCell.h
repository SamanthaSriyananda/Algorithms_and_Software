// ------------------------------------------------------------
// Draw 3D Cell
// ------------------------------------------------------------
#ifndef DRAW3DCELL_H
#define DRAW3DCELL_H

extern int meshShape;

// meshShape: 0 = triangular mesh, 1 = square / quad mesh

// ------------------------------------------------------------
// Draw shaded mesh
// ------------------------------------------------------------
// Each grid cell:
//
//     p1 ---- p2
//     | \     |
//     |  \    |
//     |   \   |
//     |    \  |
//     |     \ |
//     p4 ---- p3
//
// meshShape = 0: triangular
//     Triangle 1: p1 -> p2 -> p3
//     Triangle 2: p1 -> p3 -> p4
//
// meshShape = 1: square / quad
//     Quad: p1 -> p2 -> p3 -> p4
// ------------------------------------------------------------

inline void drawShadedMesh(int rings, int sectors, const vector<Point3D>& spherePoints)
{
    const int expectedPoints = (rings + 1) * (sectors + 1);

    if (static_cast<int>(spherePoints.size()) < expectedPoints)
    {
        cerr << "Not enough points for mesh.\n";
        return;
    }

    // Solid mode: disable transparency
    glDisable(GL_BLEND);
    glDepthMask(GL_TRUE);

    const GLfloat material[] = {0.4f, 0.2f, 0.4f, 1.0f};

    glEnable(GL_LIGHTING);   // Enable lighting
    glEnable(GL_LIGHT0);     // Enable light source
    glEnable(GL_DEPTH_TEST); // Enable depth testing
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, material);

    if (meshShape == 0)
    {
        glBegin(GL_TRIANGLES); // Draw triangular mesh

        for (int i = 0; i < rings; ++i)
        {
            const int row1 = i * (sectors + 1);
            const int row2 = row1 + sectors + 1;

            for (int j = 0; j < sectors; ++j)
            {
                const Point3D& p1 = spherePoints[row1 + j];
                const Point3D& p2 = spherePoints[row1 + j + 1];
                const Point3D& p3 = spherePoints[row2 + j + 1];
                const Point3D& p4 = spherePoints[row2 + j];

                // Triangle 1: p1 -> p2 -> p3
                glNormal3f(p1.x, p1.y, p1.z);
                glVertex3f(p1.x, p1.y, p1.z); // Draw vertex p1

                glNormal3f(p2.x, p2.y, p2.z);
                glVertex3f(p2.x, p2.y, p2.z); // Draw vertex p2

                glNormal3f(p3.x, p3.y, p3.z);
                glVertex3f(p3.x, p3.y, p3.z); // Draw vertex p3

                // Triangle 2: p1 -> p3 -> p4
                glNormal3f(p1.x, p1.y, p1.z);
                glVertex3f(p1.x, p1.y, p1.z); // Draw vertex p1

                glNormal3f(p3.x, p3.y, p3.z);
                glVertex3f(p3.x, p3.y, p3.z); // Draw vertex p3

                glNormal3f(p4.x, p4.y, p4.z);
                glVertex3f(p4.x, p4.y, p4.z); // Draw vertex p4
            }
        }

        glEnd(); // Finish triangular mesh
    }
    else
    {
        glBegin(GL_QUADS); // Draw square / quad mesh

        for (int i = 0; i < rings; ++i)
        {
            const int row1 = i * (sectors + 1);
            const int row2 = row1 + sectors + 1;

            for (int j = 0; j < sectors; ++j)
            {
                const Point3D& p1 = spherePoints[row1 + j];
                const Point3D& p2 = spherePoints[row1 + j + 1];
                const Point3D& p3 = spherePoints[row2 + j + 1];
                const Point3D& p4 = spherePoints[row2 + j];

                // Quad: p1 -> p2 -> p3 -> p4
                glNormal3f(p1.x, p1.y, p1.z);
                glVertex3f(p1.x, p1.y, p1.z); // Draw vertex p1

                glNormal3f(p2.x, p2.y, p2.z);
                glVertex3f(p2.x, p2.y, p2.z); // Draw vertex p2

                glNormal3f(p3.x, p3.y, p3.z);
                glVertex3f(p3.x, p3.y, p3.z); // Draw vertex p3

                glNormal3f(p4.x, p4.y, p4.z);
                glVertex3f(p4.x, p4.y, p4.z); // Draw vertex p4
            }
        }

        glEnd(); // Finish quad mesh
    }

    glDisable(GL_LIGHT0);   // Disable light source
    glDisable(GL_LIGHTING); // Disable lighting
}

// ------------------------------------------------------------
// Draw transparent mesh
// ------------------------------------------------------------
// Each grid cell:
//
//     p1 -------- p2
//     |        /  |
//     |      /    |
//     |    /      |
//     |  /        |
//     p4 -------- p3
//
// meshShape = 0: two triangles
// meshShape = 1: one square / quad//
// ------------------------------------------------------------

inline void drawTransparentMesh(int rings, int sectors, const vector<Point3D>& spherePoints)
{
    const int expectedPoints = (rings + 1) * (sectors + 1);

    if (static_cast<int>(spherePoints.size()) < expectedPoints)
    {
        cerr << "Not enough points for mesh.\n";
        return;
    }

    // Mesh mode: Enable transparency
    const GLfloat material[] = {0.4f, 0.2f, 0.4f, 0.35f};
    glEnable(GL_LIGHTING);   // Enable lighting
    glEnable(GL_LIGHT0);     // Enable light source
    glEnable(GL_DEPTH_TEST); // Enable depth testing
    glEnable(GL_BLEND);      // Enable transparency
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDepthMask(GL_FALSE); // Prevent transparent depth writes
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, material);

    if (meshShape == 0)
    {
        glBegin(GL_TRIANGLES); // Draw transparent triangles

        for (int i = 0; i < rings; ++i)
        {
            const int row1 = i * (sectors + 1);
            const int row2 = row1 + sectors + 1;

            for (int j = 0; j < sectors; ++j)
            {
                const Point3D& p1 = spherePoints[row1 + j];
                const Point3D& p2 = spherePoints[row1 + j + 1];
                const Point3D& p3 = spherePoints[row2 + j + 1];
                const Point3D& p4 = spherePoints[row2 + j];

                // Triangle 1: p1 -> p2 -> p3
                glNormal3f(p1.x, p1.y, p1.z);
                glVertex3f(p1.x, p1.y, p1.z); // Draw vertex p1

                glNormal3f(p2.x, p2.y, p2.z);
                glVertex3f(p2.x, p2.y, p2.z); // Draw vertex p2

                glNormal3f(p3.x, p3.y, p3.z);
                glVertex3f(p3.x, p3.y, p3.z); // Draw vertex p3

                // Triangle 2: p1 -> p3 -> p4
                glNormal3f(p1.x, p1.y, p1.z);
                glVertex3f(p1.x, p1.y, p1.z); // Draw vertex p1

                glNormal3f(p3.x, p3.y, p3.z);
                glVertex3f(p3.x, p3.y, p3.z); // Draw vertex p3

                glNormal3f(p4.x, p4.y, p4.z);
                glVertex3f(p4.x, p4.y, p4.z); // Draw vertex p4
            }
        }

        glEnd(); // Finish transparent triangles
    }
    else
    {
        glBegin(GL_QUADS); // Draw transparent quads

        for (int i = 0; i < rings; ++i)
        {
            const int row1 = i * (sectors + 1);
            const int row2 = row1 + sectors + 1;

            for (int j = 0; j < sectors; ++j)
            {
                const Point3D& p1 = spherePoints[row1 + j];
                const Point3D& p2 = spherePoints[row1 + j + 1];
                const Point3D& p3 = spherePoints[row2 + j + 1];
                const Point3D& p4 = spherePoints[row2 + j];

                // Quad: p1 -> p2 -> p3 -> p4
                glNormal3f(p1.x, p1.y, p1.z);
                glVertex3f(p1.x, p1.y, p1.z); // Draw vertex p1

                glNormal3f(p2.x, p2.y, p2.z);
                glVertex3f(p2.x, p2.y, p2.z); // Draw vertex p2

                glNormal3f(p3.x, p3.y, p3.z);
                glVertex3f(p3.x, p3.y, p3.z); // Draw vertex p3

                glNormal3f(p4.x, p4.y, p4.z);
                glVertex3f(p4.x, p4.y, p4.z); // Draw vertex p4
            }
        }

        glEnd(); // Finish transparent quads
    }

    glDepthMask(GL_TRUE);   // Restore depth writing
    glDisable(GL_BLEND);    // Disable transparency
    glDisable(GL_LIGHT0);   // Disable light source
    glDisable(GL_LIGHTING); // Disable lighting
}

// ------------------------------------------------------------
// Draw wireframe
// ------------------------------------------------------------
// Original grid:
//     +-------+-------+
//     |       |       |
//     |       |       |
//     +-------+-------+
//
// Triangular mesh:
//     +-------+-------+
//     |     / |     / |
//     |   /   |   /   |
//     | /     | /     |
//     +-------+-------+
//     |     / |     / |
//     |   /   |   /   |
//     | /     | /     |
//     +-------+-------+
//
// The diagonal p1 -> p3 is added only for triangular mesh.
// ------------------------------------------------------------

inline void drawWireframe(int rings, int sectors, const vector<Point3D>& spherePoints)
{
    glDisable(GL_LIGHTING); // Disable lighting for wireframe
    glColor3f(0.0f, 0.0f, 0.0f);
    glLineWidth(1.0f);

    // Latitude lines
    for (int i = 0; i <= rings; ++i)
    {
        glBegin(GL_LINE_STRIP); // Draw latitude line

        const int row = i * (sectors + 1);

        for (int j = 0; j <= sectors; ++j)
        {
            const Point3D& point = spherePoints[row + j];
            glVertex3f(point.x, point.y, point.z); // Draw wireframe point
        }

        glEnd(); // Finish latitude line
    }

    // Longitude lines
    for (int j = 0; j < sectors; ++j)
    {
        glBegin(GL_LINE_STRIP); // Draw longitude line

        for (int i = 0; i <= rings; ++i)
        {
            const Point3D& point = spherePoints[i * (sectors + 1) + j];
            glVertex3f(point.x, point.y, point.z); // Draw wireframe point
        }

        glEnd(); // Finish longitude line
    }

    // Diagonal lines for triangular mesh only
    if (meshShape == 0)
    {
        glBegin(GL_LINES); // Draw triangle diagonals

        for (int i = 0; i < rings; ++i)
        {
            const int row1 = i * (sectors + 1);
            const int row2 = row1 + sectors + 1;

            for (int j = 0; j < sectors; ++j)
            {
                const Point3D& p1 = spherePoints[row1 + j];
                const Point3D& p3 = spherePoints[row2 + j + 1];

                // Diagonal: p1 -> p3
                glVertex3f(p1.x, p1.y, p1.z); // Draw diagonal start
                glVertex3f(p3.x, p3.y, p3.z); // Draw diagonal end
            }
        }

        glEnd(); // Finish triangle diagonals
    }

    glEnable(GL_LIGHTING); // Restore lighting
}

// ------------------------------------------------------------
// Draw vertices / points
// ------------------------------------------------------------

inline void drawVertices(const vector<Point3D>& spherePoints)
{
    glEnable(GL_LIGHTING);   // Enable lighting
    glEnable(GL_DEPTH_TEST); // Enable depth testing
    glColor3f(0.0f, 0.0f, 0.0f);

    for (const Point3D& point : spherePoints)
    {
        glPushMatrix();
        glTranslatef(point.x, point.y, point.z);
        glutSolidSphere(0.016, 8, 8); // Draw mesh vertex
        glPopMatrix();
    }
}

// ------------------------------------------------------------
// Draw test point
// ------------------------------------------------------------

inline void drawTestPoint(const Point3D& tp, int decision)
{
    glPushAttrib(GL_ENABLE_BIT | GL_CURRENT_BIT); // Save OpenGL state
    glColor3f(1.0f, 0.75f, 0.0f);
    glDisable(GL_LIGHTING);   // Disable lighting
    glEnable(GL_DEPTH_TEST);  // Enable depth testing
    glDisable(GL_BLEND);      // Disable transparency

    if (decision == 1)
    {
        glColor3f(0.0f, 1.0f, 0.0f);    // Green = inside
    }
    else if (decision == 2)
    {
        glColor3f(1.0f, 0.0f, 0.0f);    // Red = outside
    }

    glPushMatrix();
    glTranslatef(tp.x, tp.y, tp.z);
    glutSolidSphere(0.025, 16, 16);     // Draw test point
    glPopMatrix();

    glPopAttrib(); // Restore OpenGL state
}

// ------------------------------------------------------------
// Draw complete sphere
// ------------------------------------------------------------
//
// Triangular sphere:
//
//             /\
//          __/  \__
//        /  /\  /\  \
//       /__/__\/__\__\
//       \  /\  /\  /
//        \/__\/__\/
//          \____/
//
// meshShape = 0:
// Each original quad surface is split into two triangles.
//
// meshShape = 1:
// Each original quad surface remains one square / quad.
//
// ------------------------------------------------------------

void drawSphereMesh(int rings, int sectors, const vector<Point3D>& spherePoints, int meshMode)
{
    // meshMode: 1 = solid, 0 = transparent
    if (meshMode == 1)
    {
        drawShadedMesh(rings, sectors, spherePoints); // Draw solid mesh
    }
    else
    {
        drawTransparentMesh(rings, sectors, spherePoints); // Draw transparent mesh
    }

    // These remain visible in both modes
    drawWireframe(rings, sectors, spherePoints); // Draw mesh wireframe
    drawVertices(spherePoints);                  // Draw mesh vertices
    drawSensorLabels(spherePoints);              // Draw sensor labels
    drawTestPoint(tp, decision);                 // Draw test point
}

#endif
