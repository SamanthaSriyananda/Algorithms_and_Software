#ifndef PINPHEDRON_H                                      // Header guard
#define PINPHEDRON_H                                      // Prevent duplicate inclusion

#include <algorithm>                                      // Sorting
#include <cmath>                                          // Math functions
#include <vector>                                         // Dynamic arrays

// Uses MeshDimensions from DetectDim.h / your existing project.

struct PP_V3                                              // 3D vector using double
{
    double x;                                             // X coordinate
    double y;                                             // Y coordinate
    double z;                                             // Z coordinate
};

inline PP_V3 pp_toV3(const Point3D& p) // Float to double, Converts Point3D to PP_V3
{
    return { p.x, p.y, p.z };                             // Copy coordinates; float -> double
}

inline PP_V3 pp_sub(const PP_V3& a, const PP_V3& b)       // Vector subtraction
{
    return { a.x - b.x, a.y - b.y, a.z - b.z };           // a - b
}

inline double pp_dot(const PP_V3& a, const PP_V3& b)      // Dot product
{
    return a.x * b.x + a.y * b.y + a.z * b.z;             // Returns scalar product
}

inline PP_V3 pp_cross(const PP_V3& a, const PP_V3& b)     // Cross product
{
    return {
        a.y * b.z - a.z * b.y,                            // X component
        a.z * b.x - a.x * b.z,                            // Y component
        a.x * b.y - a.y * b.x                             // Z component
    };
}

inline double pp_length(const PP_V3& v)                   // Vector length
{
    return sqrt(v.x * v.x + v.y * v.y + v.z * v.z);  // Euclidean length
}

// Check if point lies on triangle.
inline bool pp_pointOnTriangle(const PP_V3& p, const PP_V3& a, const PP_V3& b, const PP_V3& c, double tolerance)
{
    PP_V3 ab = pp_sub(b, a);                              // Edge AB
    PP_V3 ac = pp_sub(c, a);                              // Edge AC
    PP_V3 ap = pp_sub(p, a);                              // Vector A -> point

    PP_V3 n = pp_cross(ab, ac);                           // Triangle normal
    double nLen = pp_length(n);                           // Normal length

    if (nLen < 1.0e-15)                                   // Degenerate triangle
        return false;                                     // Not a valid triangle

    double distance = fabs(pp_dot(ap, n)) / nLen;    // Point-to-plane distance

    if (distance > tolerance)                             // Too far from triangle plane
        return false;                                     // Point is not on triangle

    double d00 = pp_dot(ab, ab);                          // AB · AB
    double d01 = pp_dot(ab, ac);                          // AB · AC
    double d11 = pp_dot(ac, ac);                          // AC · AC
    double d20 = pp_dot(ap, ab);                          // AP · AB
    double d21 = pp_dot(ap, ac);                          // AP · AC

    double denominator = d00 * d11 - d01 * d01;           // Barycentric denominator

    if (fabs(denominator) < 1.0e-15)                 // Degenerate triangle
        return false;                                     // Cannot calculate coordinates

    double v = (d11 * d20 - d01 * d21) / denominator;     // Barycentric V
    double w = (d00 * d21 - d01 * d20) / denominator;     // Barycentric W
    double u = 1.0 - v - w;                               // Barycentric U

    return u >= -tolerance && v >= -tolerance && w >= -tolerance; // Inside/on triangle
}


// ------------------------------------------------------------
// 3D Point-in-Polygon - Ray Casting
// ------------------------------------------------------------
inline PP_V3 pp_normalize(const PP_V3& v)                 // Normalize vector
{
    double len = pp_length(v);                            // Calculate length

    if (len < 1.0e-15)                                    // Avoid division by zero
        return { 0.0, 0.0, 0.0 };                         // Return zero vector

    return { v.x / len, v.y / len, v.z / len };           // Unit vector
}

// Ray-triangle intersection.
inline bool pp_rayTriangle(const PP_V3& origin, const PP_V3& direction, const PP_V3& a, const PP_V3& b, const PP_V3& c, double& t)
{
    const double EPSILON = 1.0e-12;                       // Intersection tolerance

    PP_V3 edge1 = pp_sub(b, a);                           // Triangle edge AB
    PP_V3 edge2 = pp_sub(c, a);                           // Triangle edge AC
    PP_V3 h = pp_cross(direction, edge2);                 // Auxiliary cross product

    double det = pp_dot(edge1, h);                        // Determinant

    if (fabs(det) < EPSILON)                         // Ray parallel to triangle
        return false;                                     // No intersection

    double invDet = 1.0 / det;                            // Inverse determinant
    PP_V3 s = pp_sub(origin, a);                          // A -> ray origin
    double u = invDet * pp_dot(s, h);                     // Barycentric U

    if (u < -EPSILON || u > 1.0 + EPSILON)                // Outside triangle
        return false;                                     // No intersection

    PP_V3 q = pp_cross(s, edge1);                         // Auxiliary vector
    double v = invDet * pp_dot(direction, q);             // Barycentric V

    if (v < -EPSILON || u + v > 1.0 + EPSILON)            // Outside triangle
        return false;                                     // No intersection

    t = invDet * pp_dot(edge2, q);                        // Distance along ray

    if (t <= EPSILON)                                     // Intersection behind/at origin
        return false;                                     // Ignore it

    return true;                                          // Valid intersection
}

// Count unique ray intersections.
inline int pp_countUniqueRayHits(vector<double>& hits)
{
    if (hits.empty())                                     // No intersections
        return 0;                                         // Return zero

    sort(hits.begin(), hits.end());                  // Sort distances

    const double HIT_TOLERANCE = 1.0e-8;                  // Duplicate-hit tolerance
    int count = 1;                                        // First hit is unique

    for (size_t i = 1; i < hits.size(); ++i)              // Check remaining hits
    {
        if (fabs(hits[i] - hits[i - 1]) > HIT_TOLERANCE) // Different hit
            ++count;                                      // Count unique hit
    }

    return count;                                         // Number of unique hits
}

// Draw one triangle.
inline void pp_drawTriangle(const PP_V3& a, const PP_V3& b, const PP_V3& c)
{
    glBegin(GL_TRIANGLES);                                // Start triangle drawing

    glVertex3d(a.x, a.y, a.z);                            // Vertex A
    glVertex3d(b.x, b.y, b.z);                            // Vertex B
    glVertex3d(c.x, c.y, c.z);                            // Vertex C

    glEnd();                                              // Finish triangle
}

/*
    Test whether ANY supplied Point3D is inside the polyhedron.
    The point comes from the main program.
*/
inline void pointInPolyhedronRayCasting(const MeshDimensions& mesh, const Point3D& tp)
{
    double surfaceTolerance = 1.0e-9;                     // Surface test tolerance
    int pointsPerRow = mesh.sectors + 1;                  // Points in each row
    int requiredPoints = (mesh.rings + 1) * pointsPerRow; // Required mesh points

    if ((int)mesh.spherePoints.size() < requiredPoints)   // Mesh data incomplete
        decision = 0;                                     // Invalid mesh

    PP_V3 p = pp_toV3(tp);                                // Convert test point
    PP_V3 ray = pp_normalize({ 1.0, 0.371, 0.217 });      // Fixed ray direction

    vector<double> hits;                             // Store ray hit distances

    for (int r = 0; r < mesh.rings; ++r)                  // Loop through rings
    {
        for (int s = 0; s < mesh.sectors; ++s)            // Loop through sectors
        {
            int i00 = r * pointsPerRow + s;               // Quad corner A
            int i01 = i00 + 1;                            // Quad corner B
            int i10 = (r + 1) * pointsPerRow + s;         // Quad corner C
            int i11 = i10 + 1;                            // Quad corner D

            PP_V3 a = pp_toV3(mesh.spherePoints[i00]);    // Convert A
            PP_V3 b = pp_toV3(mesh.spherePoints[i01]);    // Convert B
            PP_V3 c = pp_toV3(mesh.spherePoints[i10]);    // Convert C
            PP_V3 d = pp_toV3(mesh.spherePoints[i11]);    // Convert D

            // Point is directly on the surface.
            if (pp_pointOnTriangle(p, a, c, d, surfaceTolerance)) // Test triangle ACD
                decision = 1;                             // On surface

            if (pp_pointOnTriangle(p, a, d, b, surfaceTolerance)) // Test triangle ADB
                decision = 1;                             // On surface

            // Ray-triangle intersections.
            double t;                                     // Intersection distance

            if (pp_rayTriangle(p, ray, a, c, d, t))       // Ray hits ACD
                hits.push_back(t);                        // Store hit distance

            if (pp_rayTriangle(p, ray, a, d, b, t))       // Ray hits ADB
                hits.push_back(t);                        // Store hit distance
        }
    }

    int uniqueHits = pp_countUniqueRayHits(hits);         // Remove duplicate hits

    if (uniqueHits % 2) decision = 1;                     // Odd = inside
    else decision = 2;                                    // Even = outside
    // return (uniqueHits % 2) == 1;                      // Alternative return
}

// Draw the polyhedron surface.
inline void drawPolyhedronSurface(const MeshDimensions& mesh)
{
    int pointsPerRow = mesh.sectors + 1;                  // Points in each row
    int requiredPoints = (mesh.rings + 1) * pointsPerRow; // Required mesh points

    if ((int)mesh.spherePoints.size() < requiredPoints)   // Mesh data incomplete
        return;                                           // Nothing to draw

    glColor3f(0.0f, 1.0f, 0.0f);                          // Set drawing color

    for (int r = 0; r < mesh.rings; ++r)                  // Loop through rings
    {
        for (int s = 0; s < mesh.sectors; ++s)            // Loop through sectors
        {
            int i00 = r * pointsPerRow + s;               // Quad corner A
            int i01 = i00 + 1;                            // Quad corner B
            int i10 = (r + 1) * pointsPerRow + s;         // Quad corner C
            int i11 = i10 + 1;                            // Quad corner D

            PP_V3 a = pp_toV3(mesh.spherePoints[i00]);    // Convert A
            PP_V3 b = pp_toV3(mesh.spherePoints[i01]);    // Convert B
            PP_V3 c = pp_toV3(mesh.spherePoints[i10]);    // Convert C
            PP_V3 d = pp_toV3(mesh.spherePoints[i11]);    // Convert D

            pp_drawTriangle(a, c, d);                     // Draw first triangle
            pp_drawTriangle(a, d, b);                     // Draw second triangle
        }
    }
}




// ------------------------------------------------------------
// 3D Point-in-Polygon - Winding Number
// ------------------------------------------------------------
// Calculate signed solid angle of one triangle.
inline double pp_triangleSolidAngle(const PP_V3& p, const PP_V3& a, const PP_V3& b, const PP_V3& c)
{
    // Vectors from point to triangle vertices.
    PP_V3 A = pp_sub(a, p);                               // Point -> A
    PP_V3 B = pp_sub(b, p);                               // Point -> B
    PP_V3 C = pp_sub(c, p);                               // Point -> C

    double lenA = pp_length(A);                           // Distance to A
    double lenB = pp_length(B);                           // Distance to B
    double lenC = pp_length(C);                           // Distance to C

    if (lenA < 1.0e-15 || lenB < 1.0e-15 || lenC < 1.0e-15) // Point at vertex
        return 0.0;                                       // Avoid numerical problem

    // Signed determinant.
    double numerator = pp_dot(A, pp_cross(B, C));         // Signed numerator

    // Solid-angle denominator.
    double denominator =
        lenA * lenB * lenC +                              // Distance product
        pp_dot(A, B) * lenC +                             // A·B contribution
        pp_dot(B, C) * lenA +                             // B·C contribution
        pp_dot(C, A) * lenB;                              // C·A contribution

    // Signed solid angle.
    return 2.0 * atan2(numerator, denominator);      // Triangle solid angle
}

// Calculate generalized winding number.
inline double pp_windingNumber(const MeshDimensions& mesh, const PP_V3& p)
{
    const double PI = acos(-1.0);                    // Mathematical PI
    const double FOUR_PI = 4.0 * PI;                      // Full sphere solid angle

    int pointsPerRow = mesh.sectors + 1;                  // Points in each row
    double totalSolidAngle = 0.0;                         // Accumulate solid angles

    // Visit every mesh quad.
    for (int r = 0; r < mesh.rings; ++r)                  // Loop through rings
    {
        for (int s = 0; s < mesh.sectors; ++s)            // Loop through sectors
        {
            int i00 = r * pointsPerRow + s;               // Quad corner A
            int i01 = i00 + 1;                            // Quad corner B
            int i10 = (r + 1) * pointsPerRow + s;         // Quad corner C
            int i11 = i10 + 1;                            // Quad corner D

            PP_V3 a = pp_toV3(mesh.spherePoints[i00]);    // Convert A
            PP_V3 b = pp_toV3(mesh.spherePoints[i01]);    // Convert B
            PP_V3 c = pp_toV3(mesh.spherePoints[i10]);    // Convert C
            PP_V3 d = pp_toV3(mesh.spherePoints[i11]);    // Convert D

            // First triangle.
            totalSolidAngle += pp_triangleSolidAngle(p, a, c, d); // Add ACD angle

            // Second triangle.
            totalSolidAngle += pp_triangleSolidAngle(p, a, d, b); // Add ADB angle
        }
    }

    // Normalize solid angle to winding number.
    return totalSolidAngle / FOUR_PI;                     // Convert to winding number
}

// Test point using winding number.
inline void pointInPolyhedronWindingNumber(const MeshDimensions& mesh, const Point3D& tp)
{
    const double surfaceTolerance = 1.0e-9;               // Surface test tolerance

    int pointsPerRow = mesh.sectors + 1;                  // Points in each row
    int requiredPoints = (mesh.rings + 1) * pointsPerRow; // Required mesh points

    // Invalid mesh.
    if ((int)mesh.spherePoints.size() < requiredPoints)   // Check mesh size
    {
        decision = 0;                                     // Invalid mesh
        return;                                           // Stop processing
    }

    PP_V3 p = pp_toV3(tp);                                // Convert test point

    // Check if point is on surface.
    for (int r = 0; r < mesh.rings; ++r)                  // Loop through rings
    {
        for (int s = 0; s < mesh.sectors; ++s)            // Loop through sectors
        {
            int i00 = r * pointsPerRow + s;               // Quad corner A
            int i01 = i00 + 1;                            // Quad corner B
            int i10 = (r + 1) * pointsPerRow + s;         // Quad corner C
            int i11 = i10 + 1;                            // Quad corner D

            PP_V3 a = pp_toV3(mesh.spherePoints[i00]);    // Convert A
            PP_V3 b = pp_toV3(mesh.spherePoints[i01]);    // Convert B
            PP_V3 c = pp_toV3(mesh.spherePoints[i10]);    // Convert C
            PP_V3 d = pp_toV3(mesh.spherePoints[i11]);    // Convert D

            // First triangle.
            if (pp_pointOnTriangle(p, a, c, d, surfaceTolerance)) // Test ACD
            {
                decision = 1;                             // On surface
                return;                                   // Stop
            }

            // Second triangle.
            if (pp_pointOnTriangle(p, a, d, b, surfaceTolerance)) // Test ADB
            {
                decision = 1;                             // On surface
                return;                                   // Stop
            }
        }
    }

    // Calculate winding number.
    double winding = pp_windingNumber(mesh, p);           // Compute winding number

    // Inside ≈ ±1, outside ≈ 0.
    const double windingTolerance = 0.5;                  // Inside threshold

    if (fabs(winding) > windingTolerance)            // Non-zero winding
        decision = 1;  // Inside                          // Point is inside
    else
        decision = 2;  // Outside                         // Point is outside
}

#endif // PINPHEDRON_H                                    // End header guard