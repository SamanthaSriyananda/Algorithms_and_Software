#include "3DFiles/IanfraStruct/IanfraStruct.h"
#include "3DFiles/Algorithms.h"

int meshMode = 0; // 1 = solid, 0 = transparent
int meshShape = 0; // 1 = square, 0 = triangle

// ------------------------------------------------------------
// Main
// ------------------------------------------------------------
int main(int argc, char** argv) {
    system("cls");

    // SpherePointsPlus(PI, 20, 30); // Generate sphere points rings = 10, sectors = 20. Can be rings = 20, sectors = 30
    MeshDimensions mesh = detectMeshDimensions("3DFiles/IanfraStruct/sphere_pointsPlus.txt", PI, TWO_PI);
    // MeshDimensions mesh = detectMeshDimensions("Points_Cloud.txt", PI, TWO_PI);
    // SpherePoints(PI, 20, 30); // Generate sphere points rings = 10, sectors = 20. Can be rings = 20, sectors = 30
    // MeshDimensions mesh = detectMeshDimensions("3DFiles/IanfraStruct/sphere_points.txt", PI, TWO_PI);

    // GUI
    // ------------------------------------------------------------
    // OpenGL Window Initialization
    // ------------------------------------------------------------
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(900, 700);               // Initial window size on the screen
    glutInitWindowPosition(100, 50);            // Position the window on the screen
    glutCreateWindow("3D Point-in-Polyhedron"); // Window title

    initOpenGL();
    installMouseWindowProc();

    spherePoints = mesh.spherePoints;   // To be used in "display"
    rings = mesh.rings;
    sectors = mesh.sectors;             // To be used in "display"

    glutDisplayFunc(display);           // Register function to display the scene
    glutReshapeFunc(reshape);           // Register function to handle window resizing
    glutKeyboardFunc(keyboard);         // Register function to handle keyboard input
    glutMouseFunc(mouseButton);         // Register function to handle mouse button events
    glutMotionFunc(mouseMotion);        // Register function to handle mouse motion events

    // Start console input on a separate thread
    thread inputThread([&mesh]()
    {
        while (true){
            
            cout << "\nEnter the point to test (x, y, z) (e.g., 0.5, 0.5, 0.5)" << endl;
            cout << "Default visible range for each coordinate: -1.5 - 1.5 " << endl;
            cout << "Point colors - Inside: Green, Outside: Red " << endl;
            cout << "Press \"Esc\" to exit" << endl;

            if (readCoordinates("x: ", tp.x)) break;
            if (readCoordinates("y: ", tp.y)) break;
            if (readCoordinates("z: ", tp.z)) break;
            
            // tp.x = 0.5f; tp.y = 0.5f; tp.z =  0.5f; // Test Point
            // ------------------------------------------------------------
            // 3D Point-in-Polygon
            // ------------------------------------------------------------
            cudaPointInPolyhedronRayCasting(mesh, tp);    //  Ray Casting
            // ------------------------------------------------------------
            // cudaPointInPolyhedronWindingNumber(mesh, tp); //  Winding Number
            
            if (decision == 1)
                cout << "Point is INSIDE the polyhedron.\n\n";
            else if (decision == 2)
                cout << "Point is OUTSIDE the polyhedron.\n\n";
            else
                cout << "No algorithm.\n\n";            
            
            glutPostRedisplay();        // Notify the OpenGL thread to refresh the display
            // _getch();                   // Pause at this line
        }
    }); // No joining is needed for this thread as it blocks the thread displaying the output window

    glutMainLoop(); // Listen to events (e.g., keyboard, mouse, window resize) and call the registered functions

    return 0;
}


// ==================================================================
// (C) Samantha Sriyananda
// Contact: mgssriyananda@gmail.com